export default function MesaLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
